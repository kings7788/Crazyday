package com.web.store.exception;

public class ProductNotFoundException extends RuntimeException{
	Integer bookId;

	public ProductNotFoundException(Integer bookId) {
		super();
		this.bookId = bookId;
	}

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}
	
}
